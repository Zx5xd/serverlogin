package com.example.serverlogin.flg;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;
import com.example.serverlogin.sns.BoardDto;
import com.example.serverlogin.sns.listItemAdapter;

import java.net.MalformedURLException;
import java.net.URL;

public class ReadBoard extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private View view;
    String path; URL url;
    SwipeRefreshLayout swipe;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.board_read,container,false);

        allboard();

        swipe = view.findViewById(R.id.swipe);
        swipe.setOnRefreshListener(this);


        return view;
    }

    private void addAdapter(String s){
        ListView lv = view.findViewById(R.id.lv);
        listItemAdapter adapter= new listItemAdapter();
        adapter.getOthercontext(view.getContext());
        String[] sp = s.trim().split("//.//");

        for(int i=0; i<sp.length; i++){
            System.out.println(sp[i]);
            //spvalue+=sp[i];
        }
        String spno="",spcontent="", spnick="", sprecom="", spregdate="";

        for(int i=0; i<sp.length; i++){
            if(sp[i].matches(".*no_.*")){
                spno += sp[i];
            }
            else if(sp[i].matches(".*cont_.*")){
                spcontent += sp[i];
            }else if(sp[i].matches(".*nick_.*")){
                spnick += sp[i];
            }else if(sp[i].matches(".*recom_.*")){
                sprecom += sp[i];
            }else if(sp[i].matches(".*reg_.*")){
                spregdate += sp[i];
            }
        }
        final String[] NoArray = spno.split("no_");
        final String[] ContentArray = spcontent.split("cont_");
        String[] NickArray = spnick.split("nick_");
        String[] RecomArray = sprecom.split("recom_");
        String[] regDateArray = spregdate.split("reg_");

        for(int i=0; i<NoArray.length-1; i++){
            System.out.println("NoArray: "+NoArray[i]);

            adapter.addItem(new BoardDto(NoArray[i+1],ContentArray[i+1],NickArray[i+1],regDateArray[i+1],RecomArray[i+1], null));
        }
        adapter.notifyDataSetChanged();
        lv.setAdapter(adapter);

    }

    public void allboard(){
        try {
            System.out.println("allboard"+getResources().getString(R.string.allboard_url));
            path = getResources().getString(R.string.allboard_url);
            url = new URL(path);
            new HttpConnection().execute(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRefresh() {
        swipe.setRefreshing(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                allboard();
                swipe.setRefreshing(false);
            }
        },1000);
    }

    private class HttpConnection extends AsyncTask<URL, Integer, String> {

        @Override
        protected void onPostExecute(final String s) {
            super.onPostExecute(s);

            Log.d(this.getClass().getName(), "onPostExecute: "+s);

            addAdapter(s);

//            if(recyle==false){
//                CardView(s);
//            }else{
//                onRestart();
//            }


        }

        @Override
        protected String doInBackground(URL... urls) {
            String data = "";

            if (urls.length == 0)
                return "URL is empty";

            try {
                RequestHttpURLConnection connection = new RequestHttpURLConnection();
                data = connection.request(urls[0]);
            } catch (Exception e) {
                data = e.getMessage();
            }

            return data;
        }
    }
}
