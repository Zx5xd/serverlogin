package com.example.serverlogin.flg;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;
import com.example.serverlogin.login.Login;
import com.example.serverlogin.sns.Board;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class WriteBoard extends Fragment {
    private View view;
    String nick,classify;
    TextView nickName;
    EditText content;
    Button writing;
    Spinner kind;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.board_write,container,false);

       nick = Login.session.getString("userNick","");

        nickName = view.findViewById(R.id.cbnick);
        content = view.findViewById(R.id.cbcontent);
        writing = view.findViewById(R.id.writing);
        kind = view.findViewById(R.id.spinner);



        nickName.setText(nick);

        kind.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                classify = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                classify = parent.getItemAtPosition(0).toString();
            }
        });

       content.addTextChangedListener(new TextWatcher() {
           @Override
           public void beforeTextChanged(CharSequence s, int start, int count, int after) {

           }

           @Override
           public void onTextChanged(CharSequence s, int start, int before, int count) {
               if(content.getText().toString().length() == 0) {
                   writing.setClickable(false);
                   writing.setBackgroundColor(getResources().getColor(R.color.write_button));
               }else {
                   writing.setClickable(true);
                   writing.setBackgroundColor(Color.RED);
                   writing.setOnClickListener(new View.OnClickListener() {
                       @Override
                       public void onClick(View v) {
                           try {
                               LinkHttp link = new LinkHttp();
                               String path = getResources().getString(R.string.addboard_url);
                               URL url = link.BoardLink(path,null,content.getText().toString(),nick,classify,null);
                               content.setText("");
                               new HttpConnection().execute(url);

                           } catch (MalformedURLException | UnsupportedEncodingException e) {
                               e.printStackTrace();
                           }
                       }
                   });

               }
           }

           @Override
           public void afterTextChanged(Editable s) {

           }
       });

        return view;
    }

    private class HttpConnection extends AsyncTask<URL, Integer, String> {

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.trim().equals("게시 성공")){
                Intent intent = new Intent(view.getContext(),Board.class);
                startActivity(intent);
            }
        }

        @Override
        protected String doInBackground(URL... urls) {
            String data = "";

            if (urls.length == 0)
                return "URL is empty";

            try {
                RequestHttpURLConnection connection = new RequestHttpURLConnection();
                data = connection.request(urls[0]);
            } catch (Exception e) {
                data = e.getMessage();
            }

            return data;
        }
    }

}
