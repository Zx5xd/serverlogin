package com.example.serverlogin;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;

public class RequestHttpURLConnection {
    public String request(URL url) {
        HttpURLConnection urlConnection = null;
        Log.d(this.getClass().getName(), "request: "+url.toString());
        try{
            urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setReadTimeout(3000);
            urlConnection.setConnectTimeout(3000);

           String page = "";
           try(BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream(),"UTF-8"))){
               String line;
               while((line = reader.readLine()) != null){
                   page += line;
               }
               return page;
           }catch(Exception e){
               e.printStackTrace();
           }
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
