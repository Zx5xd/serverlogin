package com.example.serverlogin.sns;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.serverlogin.DefaultAlertBuild;
import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;
import com.example.serverlogin.login.Login;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class Chat extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    String s; String[] sp;
    Button btn_send; boolean click = false;
    EditText chat_etc;
    SwipeRefreshLayout swipe;
    LinkHttp link = new LinkHttp();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.board_chatscreen);

        btn_send = findViewById(R.id.btn_send);
        chat_etc = findViewById(R.id.chat_etc);
        swipe = findViewById(R.id.swipe);
        swipe.setOnRefreshListener(this);



        Intent getintent = getIntent();
        s = getintent.getStringExtra("Info");
        sp = s.trim().split("___");

        System.out.println("sp[0]: "+sp.length);
        //System.out.println("sp[1]: "+sp[1]);

        if(sp.length>1){
            addInfoAdapter(sp[0]);
            addChatAdapter(sp[1]);
        }else {
            addInfoAdapter(sp[0]);
        }

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click = true;
                onRefresh();
            }
        });

    }
    private void addInfoAdapter(String s){
        ListView lv = findViewById(R.id.infoView);
        listItemAdapter adapter= new listItemAdapter();
        //adapter.getOthercontext(this);
        String[] sp = s.trim().split("//.//");

        for(int i=0; i<sp.length; i++){
            System.out.println(sp[i]);
            //spvalue+=sp[i];
        }
        String spno="",spcontent="", spnick="", sprecom="", spregdate="";

        for(int i=0; i<sp.length; i++){
            if(sp[i].matches(".*no_.*")){
                spno += sp[i];
            }
            else if(sp[i].matches(".*cont_.*")){
                spcontent += sp[i];
            }else if(sp[i].matches(".*nick_.*")){
                spnick += sp[i];
            }else if(sp[i].matches(".*recom_.*")){
                sprecom += sp[i];
            }else if(sp[i].matches(".*reg_.*")){
                spregdate += sp[i];
            }
        }
        final String[] NoArray = spno.split("no_");
        final String[] ContentArray = spcontent.split("cont_");
        String[] NickArray = spnick.split("nick_");
        String[] RecomArray = sprecom.split("recom_");
        String[] regDateArray = spregdate.split("reg_");

        for(int i=0; i<NoArray.length-1; i++){
            System.out.println("NoArray: "+NoArray[i]);
            adapter.addItem(new BoardDto(NoArray[i+1],ContentArray[i+1],NickArray[i+1],regDateArray[i+1],RecomArray[i+1], null));
        }
        adapter.notifyDataSetChanged();
        lv.setAdapter(adapter);
    }

    private void addChatAdapter(String s){
        ListView lv = findViewById(R.id.chatview);
        lv.setVisibility(View.VISIBLE);
        ChatItemAdapter adapter= new ChatItemAdapter();
        //adapter.getOthercontext(this);
        String[] sp = s.trim().split("//.//");

        for(int i=0; i<sp.length; i++){
            System.out.println(sp[i]);
            //spvalue+=sp[i];
        }
        String spno="",spchat="", spnick="", spregdate="";

        for(int i=0; i<sp.length; i++){
            if(sp[i].matches(".*no_.*")){
                spno += sp[i];
            }
            else if(sp[i].matches(".*chat_.*")){
                spchat += sp[i];
            }else if(sp[i].matches(".*nick_.*")){
                spnick += sp[i];
            }else if(sp[i].matches(".*reg_.*")){
                spregdate += sp[i];
            }
        }
        final String[] NoArray = spno.split("no_");
        final String[] ChatArray = spchat.split("chat_");
        String[] NickArray = spnick.split("nick_");
        String[] regDateArray = spregdate.split("reg_");

        for(int i=0; i<NoArray.length; i++){
            System.out.println("NoArray["+i+"]: "+NoArray[i]);
            System.out.println("ChatArray["+i+"]: "+ChatArray[i]);
            System.out.println("NickArray["+i+"]: "+NickArray[i]);
            System.out.println("regDateArray["+i+"]: "+regDateArray[i]);
        }

        for(int i=0; i<NoArray.length-1; i++){
            System.out.println("NoArray: "+NoArray[i]);

            adapter.addItem(new ChatDto(NoArray[i+1],ChatArray[i+1],NickArray[i+1],regDateArray[i+1]));
        }
        adapter.notifyDataSetChanged();
        lv.setAdapter(adapter);
    }

    @Override
    public void onRefresh() {
        swipe.setRefreshing(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                String id = Login.session.getString("userId","");
                String chatno = Login.session.getString("ChatNo","");
                System.out.println("userId session:"+id);
                System.out.println("ChatNo session:"+chatno);
                if(click == true){
                    if(id.equals("")) {
                        DefaultAlertBuild alert = new DefaultAlertBuild();
                        alert.ChageView("오류발생","Error",Chat.this, Login.class);
                        Login.id.clear();
                        Login.id.commit();
                    }else{
                        try { click = false;
                            URL url = link.BoardLink(getResources().getString(R.string.setcominfo_url),chatno,chat_etc.getText().toString(),null,null,id);// id를 no대신 전송
                            new HttpConnection().execute(url);

                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                    }
                } else{
                    try {
                        URL url = link.BoardLink(getResources().getString(R.string.getcominfo_url),chatno,null,null,null,null);
                        new HttpConnection().execute(url);

                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                }

                swipe.setRefreshing(false);
            }
        },1000);
    }

    private class HttpConnection extends AsyncTask<URL, Integer, String> {

        @Override
        protected void onPostExecute(final String s) {
            super.onPostExecute(s);

            sp = s.trim().split("___");

            if(sp.length>1){
                addInfoAdapter(sp[0]);
                addChatAdapter(sp[1]);
            }else {
                addInfoAdapter(sp[0]);
            }

        }

        @Override
        protected String doInBackground(URL... urls) {
            String data = "";

            if (urls.length == 0)
                return "URL is empty";

            try {
                RequestHttpURLConnection connection = new RequestHttpURLConnection();
                data = connection.request(urls[0]);
            } catch (Exception e) {
                data = e.getMessage();
            }

            return data;
        }
    }
}
