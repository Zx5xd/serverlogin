package com.example.serverlogin.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.RequestHttpURLConnection;
import com.example.serverlogin.sns.Board;
import com.example.serverlogin.R;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class Login extends AppCompatActivity {

   public static SharedPreferences session;
   public static SharedPreferences.Editor id;
    TextView findId, findPwd, join;
    EditText id_etc, pwd_etc;
    Button btn_send;
    Switch autologin;
    URL url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final LinkHttp link = new LinkHttp();

        id_etc = findViewById(R.id.id_etc); pwd_etc = findViewById(R.id.pwd_etc);
        btn_send = findViewById(R.id.btn_send);
        autologin = findViewById(R.id.autologin);
        findId = findViewById(R.id.findId); findPwd = findViewById(R.id.findPwd);
        join = findViewById(R.id.join);

       // final String filename = "autologinText.txt";
       // final String filePath = getApplicationContext().getFilesDir().getPath().toString() + filename;


        if((session = getApplicationContext().getSharedPreferences("session",MODE_PRIVATE))
                .getString("autoLoginId","") != ""){
            try {
                url = link.LinkHttp(getResources().getString(R.string.login_url), session.getString("autoLoginId",""),
                        session.getString("autoLoginPwd",""), null);
                new HttpConnection().execute(url);
            } catch (MalformedURLException | UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        btn_send.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
               /*     try {
                        //  auotoLoginFunction.writetext(id_etc.getText().toString(),pwd_etc.getText().toString());

                        path = getResources().getString(R.string.loginCheck_url) + "?id=";
                        query = URLEncoder.encode(id_etc.getText().toString(), "UTF-8") + "&pwd=" +
                                URLEncoder.encode(pwd_etc.getText().toString(), "UTF-8");
                        url = new URL(path + query);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }*/
                    try {
                        url = link.LinkHttp(getResources().getString(R.string.login_url), id_etc.getText().toString(), pwd_etc.getText().toString(), null);
                        new HttpConnection().execute(url);
                    } catch (MalformedURLException | UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
          /*      if (test.getText().toString().trim().equals("Cookie 생성 종료")) {
                    URL url = null;
                    try {
                        url = new URL(getResources().getString(R.string.login_url));

                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    new HttpConnection().execute(url);
                }*/
            }
        });

        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),Join.class);
                startActivity(intent);

                /*try {
                    url = LinkHttp(getResources().getString(R.string.join_url));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                new HttpConnection().execute(url);*/
            }
        });

        findId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),FindId.class);
                startActivity(intent);
            }
        });

        findPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),FindPwd.class);
                startActivity(intent);
            }
        });
    }


    private class HttpConnection extends AsyncTask<URL, Integer, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (s.trim().equals("로그인 실패")) {
                Toast.makeText(getApplicationContext(), "일치하는 정보가 없습니다.", Toast.LENGTH_SHORT).show();
            } else {
                session = getSharedPreferences("session",MODE_PRIVATE);  // 세션이름 및 모드 설정
                id = session.edit(); // 데이터 저장 및 수정 객체
                id.putString("userId",id_etc.getText().toString()) // 데이터 저장. id란에 id_etc.getText().toString()을
                  .putString("userNick",s.trim()).commit(); // 저장

                if(autologin.isChecked() == true) {
                  id.putString("autoLoginId", id_etc.getText().toString())
                    .putString("autoLoginPwd", pwd_etc.getText().toString())
                    .commit();
                }

                Log.d(this.getClass().getName(), "onPostExecute login: "+s);
                Toast.makeText(getApplicationContext(), s.trim() + "님 환영합니다.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), Board.class);
                startActivity(intent);
            }
        }

        @Override
        protected String doInBackground(URL... urls) {
            String data = "";

            if (urls.length == 0)
                return "URL is empty";

            try {
                RequestHttpURLConnection connection = new RequestHttpURLConnection();
                data = connection.request(urls[0]);
            } catch (Exception e) {
                data = e.getMessage();
            }

            return data;
        }
    }

}

