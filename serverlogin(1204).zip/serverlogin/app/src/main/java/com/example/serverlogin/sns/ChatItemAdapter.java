package com.example.serverlogin.sns;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class ChatItemAdapter extends BaseAdapter {
    ArrayList<ChatDto> chatItem = new ArrayList<ChatDto>();
    Context context, othercontext;
    @Override
    public int getCount() {
        return chatItem.size();
    }

    @Override
    public Object getItem(int position) {
        return chatItem.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        context = parent.getContext();
        ChatDto item = chatItem.get(position);

        if(convertView == null){
            LayoutInflater inf = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            // LayoutInflater 사용 준비단계
            convertView = inf.inflate(R.layout.listview_chat,parent,false);
            // ViewGroup 내 있는 자식뷰들을 객체화 시켜 레이아웃에 된
            // 레이아웃을 converView에 복붙.
        }

        // ViewGroup에 속한 View 설정
        final TextView no = convertView.findViewById(R.id.no);
        final TextView chat = convertView.findViewById(R.id.chat);
        final TextView nick = convertView.findViewById(R.id.nickName);
        final TextView regdate = convertView.findViewById(R.id.regdate);

        no.setText(item.getNo());
        nick.setText(item.getNickName());
        regdate.setText(item.getRegdate());
        chat.setText(item.getChat());

        // 추천 이미지 클릭시 addRecom.jsp(추천수 증가페이지) 이동

        // System.out.println("listItemAdapter no: "+no.getText().toString());

        return convertView;
    }

    public void getOthercontext(Context context){
        this.othercontext = context;
    }

    // 자식뷰 value값 불러온다. (SNS 클래스로 이동)
    public void addItem(ChatDto item){
        chatItem.add(item);
    }

}
