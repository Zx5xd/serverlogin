package com.example.serverlogin.sns;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.serverlogin.DefaultAlertBuild;
import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;
import com.example.serverlogin.login.Login;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class UpdateBoard extends AppCompatActivity {

    String getContent, getNo, getNick, getRegdate, classify;
    EditText Content; TextView Nick, Regdate;
    ImageView BoardDelete;
    Spinner spinner;
    Button updating;
    DefaultAlertBuild alert = new DefaultAlertBuild();
    LinkHttp link = new LinkHttp();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.board_update);

        getContent = Login.session.getString("BoardContent","");
        getNick = Login.session.getString("userNick","");
        getNo = Login.session.getString("BoardNo","");
        getRegdate = Login.session.getString("BoardRegdate","");

        Content = findViewById(R.id.ubcontent);
        Nick = findViewById(R.id.ubnick);
        updating = findViewById(R.id.updating);
        Regdate = findViewById(R.id.regdate);
        BoardDelete = findViewById(R.id.BoardDelete);

        if(getNick != null){
            Nick.setText(getNick);
        }else{
            Intent intent = new Intent(getApplicationContext(),Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }

        if(getNo == null){
            alert.ChageView("에러가 발생했습니다.\n앱 종료 후 다시 시도해주세요.","Error",UpdateBoard.this,Board.class);
        }else{
            if(getContent != null | getRegdate != null) {
                Content.setText(getContent);
                Regdate.setText(getRegdate);
            }else{
                alert.DefaultAlert("죄송합니다.\n기록 불러오는데 실패하였습니다.\n그러나 수정은 진행하셔도 됩니다.","Error",UpdateBoard.this);
            }
        }

        spinner = findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                classify = spinner.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                classify = spinner.getItemAtPosition(0).toString();
            }
        });

        Content.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(Content.getText().toString().length() == 0) {
                    updating.setClickable(false);
                    updating.setBackgroundColor(getResources().getColor(R.color.write_button));
                }else {
                    updating.setClickable(true);
                    updating.setBackgroundColor(Color.RED);
                    updating.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            try {

                                String path = getResources().getString(R.string.updateboard_url);
                                URL url = link.BoardLink(path,getNo,Content.getText().toString(),null,classify,null);
                                new HttpConnection().execute(url);

                            } catch (MalformedURLException | UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        BoardDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("BoardDelete onClick");
                AlertDialog.Builder deleteBuilder = new AlertDialog.Builder(UpdateBoard.this);
                deleteBuilder.setTitle("삭제하시겠습니까?");
                deleteBuilder.setMessage("삭제하시면 해당 글을 다시 복구하실 수 없습니다.\n정말로 삭제하시겠습니까?");
                deleteBuilder.setPositiveButton("취소", null);
                deleteBuilder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try{
                            String path = getResources().getString(R.string.deleteboard_url);
                            URL url = link.BoardLink(path,getNo,null,null,null,null);
                            new HttpConnection().execute(url);
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                    }
                });
                AlertDialog deleteDialog = deleteBuilder.create();
                deleteDialog.show();
            }

        });

    }

    private class HttpConnection extends AsyncTask<URL, Integer, String> {

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if(s.trim().equals("수정 성공")){
                Login.id.remove("BoardNo")
                        .remove("BoardContent")
                        .remove("BoardRegdate")
                        .commit();
                alert.ChageView("게시글 수정이 성공적으로 완료되었습니다.","게시글 수정 성공",UpdateBoard.this,Board.class);
            }else if(s.trim().equals("삭제 성공")){
                Login.id.remove("BoardNo")
                        .remove("BoardContent")
                        .remove("BoardRegdate")
                        .commit();
                alert.ChageView("게시글 삭제가 성공적으로 완료되었습니다.","게시글 삭제 성공",UpdateBoard.this,Board.class);
            } else{
                alert.DefaultAlert("System Error", "Error", UpdateBoard.this);
                Intent intent = new Intent(UpdateBoard.this, Board.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }

        @Override
        protected String doInBackground(URL... urls) {
            String data = "";

            if(urls.length == 0)
                return "URL is Empty";

            try {
                RequestHttpURLConnection connection = new RequestHttpURLConnection();
                data = connection.request(urls[0]);
            } catch (Exception e) {
                data = e.getMessage();
            }

            return data;
        }
    }
}
