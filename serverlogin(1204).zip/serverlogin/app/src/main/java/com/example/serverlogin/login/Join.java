package com.example.serverlogin.login;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.serverlogin.DefaultAlertBuild;
import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class Join extends AppCompatActivity {

    Button fin;
    EditText id_etc,pwd_etc,nick_etc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_join);

        id_etc = findViewById(R.id.id_etc);
        pwd_etc = findViewById(R.id.pwd_etc);
        nick_etc = findViewById(R.id.nick_etc);
        fin = findViewById(R.id.btn_send);

        final LinkHttp link = new LinkHttp();
        fin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                URL url = null;
                try {
                   url = link.LinkHttp(getResources().getString(R.string.join_url),id_etc.getText().toString(),pwd_etc.getText().toString(),nick_etc.getText().toString());
                } catch (MalformedURLException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                new HttpConnection().execute(url);
            }
        });

    }

    private class HttpConnection extends AsyncTask<URL, Integer, String>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DefaultAlertBuild alertBuild = new DefaultAlertBuild();
            if(s.trim().equals("회원가입 실패")){
                alertBuild.DefaultAlert("가입에 실패하셨습니다. \n다시 시도해주십시오.",s.trim(),Join.this);
            }else{
                alertBuild.ChageView("회원가입이 성공적으로 마쳤습니다. \n로그인하십시오.","회원가입 완료",Join.this, Login.class);
            }
        }

        @Override
        protected String doInBackground(URL... urls) {
            String data = "";

            if(urls.length==0)
                return "URL is empty";

            try{
                RequestHttpURLConnection connection = new RequestHttpURLConnection();
                data = connection.request(urls[0]);
            } catch (Exception e){
                data = e.getMessage();
            }

            return data;
        }
    }
}