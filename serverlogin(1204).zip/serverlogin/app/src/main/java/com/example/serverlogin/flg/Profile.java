package com.example.serverlogin.flg;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.example.serverlogin.LinkHttp;
import com.example.serverlogin.R;
import com.example.serverlogin.RequestHttpURLConnection;
import com.example.serverlogin.login.Login;
import com.example.serverlogin.sns.BoardDto;
import com.example.serverlogin.sns.ProfilelistAapter;
import com.example.serverlogin.login.UpdateInfo;
import com.example.serverlogin.sns.UpdateBoard;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class Profile extends Fragment {

    private View Rootview;
    TextView profileNick;
    Button userInfo, logout;
    LinkHttp link = new LinkHttp();
    String path; URL url;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Rootview = inflater.inflate(R.layout.profile,container,false);

        String nick = Login.session.getString("userNick","");

        profileNick = Rootview.findViewById(R.id.profileNick);
        userInfo = Rootview.findViewById(R.id.userInfo);
        logout = Rootview.findViewById(R.id.logout);

        if(nick != null)
        profileNick.setText(nick);

        userInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Rootview.getContext(), UpdateInfo.class);
                startActivity(intent);

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login.id.clear();
                Login.id.commit();
            Intent intent = new Intent(Rootview.getContext(),Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            }
        });

        try{
                path = getResources().getString(R.string.profile_url);
                url = link.BoardLink(path, null,null,nick,null,null);
            new HttpConnection().execute(url);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return Rootview;
    }
    private void InfoAdapter(String s){
        ListView lv = Rootview.findViewById(R.id.myboard);
        lv.setLongClickable(true);

        final ProfilelistAapter adapter= new ProfilelistAapter();
        adapter.getOthercontext(Rootview.getContext());
        String[] sp = s.trim().split("//.//");

        for(int i=0; i<sp.length; i++){
            System.out.println(sp[i]);
            //spvalue+=sp[i];
        }
        String spno="",spcontent="", spnick="", sprecom="", spregdate="", spopen="";

        for(int i=0; i<sp.length; i++){
            if(sp[i].matches(".*no_.*")){
                spno += sp[i];
            }
            else if(sp[i].matches(".*cont_.*")){
                spcontent += sp[i];
            }else if(sp[i].matches(".*nick_.*")){
                spnick += sp[i];
            }else if(sp[i].matches(".*recom_.*")){
                sprecom += sp[i];
            }else if(sp[i].matches(".*reg_.*")){
                spregdate += sp[i];
            } else if (sp[i].matches((".*open_.*"))) {
                spopen += sp[i];
            }
        }
        final String[] NoArray = spno.split("no_");
        final String[] ContentArray = spcontent.split("cont_");
        String[] NickArray = spnick.split("nick_");
        String[] RecomArray = sprecom.split("recom_");
        final String[] regDateArray = spregdate.split("reg_");
        String[] OpenArray = spopen.split("open_");

        for(int i=0; i<NoArray.length-1; i++){
            System.out.println("NoArray: "+NoArray[i]);
            adapter.addItem(new BoardDto(NoArray[i+1],ContentArray[i+1],NickArray[i+1],regDateArray[i+1],RecomArray[i+1],OpenArray[i+1]));
        }

        adapter.notifyDataSetChanged();
        lv.setAdapter(adapter);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                System.out.println("LoginClick!");
                adapter.setPopupMenu(Rootview.getContext(),view);
                return false; }
        });
    }
            private class HttpConnection extends AsyncTask<URL, Integer, String> {

                @Override
                protected void onPostExecute(final String s) {
                    super.onPostExecute(s);

                    InfoAdapter(s);
                    Log.d(this.getClass().getName(), "onPostExecute: " + s);


                }

                @Override
                protected String doInBackground(URL... urls) {
                    String data = "";

                    if (urls.length == 0)
                        return "URL is empty";

                    try {
                        RequestHttpURLConnection connection = new RequestHttpURLConnection();
                        data = connection.request(urls[0]);
                    } catch (Exception e) {
                        data = e.getMessage();
                    }

                    return data;
                }
            }
        }

